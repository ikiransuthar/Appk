import React from 'react';
import { ArrowDownLeft, ArrowUpRight, Scale, Calendar, HelpCircle } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { TimeFilter } from '../types';

interface SummaryCardsProps {
  totalTaken: number;
  totalGiven: number;
  netBalance: number;
  activeFilter: TimeFilter;
  onFilterChange: (filter: TimeFilter) => void;
  filteredCount: number;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({
  totalTaken,
  totalGiven,
  netBalance,
  activeFilter,
  onFilterChange,
  filteredCount,
}) => {
  const filters: { id: TimeFilter; label: string }[] = [
    { id: 'today', label: 'Today' },
    { id: 'yesterday', label: 'Yesterday' },
    { id: 'week', label: '7 Days' },
    { id: 'month', label: 'This Month' },
    { id: 'all', label: 'All Records' },
  ];

  return (
    <section className="space-y-3">
      {/* Time Range Selector */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center space-x-1.5 overflow-x-auto py-1 scrollbar-none">
          {filters.map((f) => {
            const isActive = activeFilter === f.id;
            return (
              <button
                key={f.id}
                onClick={() => onFilterChange(f.id)}
                className={`px-3 py-1 text-xs font-mono rounded transition shrink-0 ${
                  isActive
                    ? 'bg-white text-black font-semibold border border-white'
                    : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-900 hover:border-zinc-700'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>

        <div className="text-[11px] font-mono text-zinc-400 flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5" />
          <span>{filteredCount} {filteredCount === 1 ? 'entry' : 'entries'} in view</span>
        </div>
      </div>

      {/* 3 Core Summary Cards: Taken, Given, Net Balance */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Total Amount Taken */}
        <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-950/80 relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Total Taken (Received)
            </span>
            <div className="w-7 h-7 rounded-full bg-white text-black flex items-center justify-center font-bold">
              <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-white">
              {formatCurrency(totalTaken)}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-zinc-300">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-white"></span>
              <span>Cash In / Repair / Sales / Transfer IN</span>
            </div>
          </div>
        </div>

        {/* Total Amount Given */}
        <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-950/80 relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Total Given (Paid / Sent)
            </span>
            <div className="w-7 h-7 rounded-full border border-zinc-700 bg-black text-white flex items-center justify-center font-bold">
              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-zinc-200">
              {formatCurrency(totalGiven)}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-zinc-300">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-zinc-400"></span>
              <span>Cash Out / Remittance Sent / Udhaar</span>
            </div>
          </div>
        </div>

        {/* Net Balance */}
        <div className="p-4 rounded-xl border-2 border-white bg-black relative overflow-hidden flex flex-col justify-between shadow-[0_4px_20px_rgba(255,255,255,0.06)]">
          <div className="flex items-center justify-between pb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-white font-bold flex items-center gap-1">
              <Scale className="w-3.5 h-3.5" />
              Net Balance
            </span>
            <span className="text-[10px] font-mono tracking-widest uppercase px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-zinc-300">
              {netBalance >= 0 ? 'SURPLUS' : 'DEFICIT'}
            </span>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-white flex items-center gap-1">
              <span>{netBalance >= 0 ? '+' : '-'}</span>
              <span>{formatCurrency(Math.abs(netBalance))}</span>
            </div>
            <div className="mt-1 text-[11px] font-mono text-zinc-400 flex items-center justify-between">
              <span>Taken minus Given</span>
              <span className="text-zinc-200 font-semibold">
                {netBalance >= 0 ? 'Till Positive' : 'Credit Due'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
