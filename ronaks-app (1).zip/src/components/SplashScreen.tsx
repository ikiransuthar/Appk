import React, { useEffect, useState } from 'react';
import { ShieldCheck, ArrowRight, Smartphone } from 'lucide-react';

interface SplashScreenProps {
  onDismiss: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onDismiss }) => {
  const [fadeState, setFadeState] = useState<'visible' | 'fading' | 'hidden'>('visible');

  useEffect(() => {
    // Automatically fade out after 1800ms
    const timer = setTimeout(() => {
      setFadeState('fading');
      setTimeout(() => {
        onDismiss();
      }, 400);
    }, 1800);

    return () => clearTimeout(timer);
  }, [onDismiss]);

  const handleManualDismiss = () => {
    setFadeState('fading');
    setTimeout(() => {
      onDismiss();
    }, 250);
  };

  if (fadeState === 'hidden') return null;

  return (
    <div
      onClick={handleManualDismiss}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between bg-black p-6 transition-opacity duration-400 cursor-pointer select-none ${
        fadeState === 'fading' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Top Tagline */}
      <div className="w-full max-w-sm flex items-center justify-between border-b border-zinc-800 pt-8 pb-3">
        <span className="text-[10px] tracking-[0.25em] uppercase text-zinc-400 font-mono">RADHE MOBILE LEDGER</span>
        <span className="text-[10px] tracking-wider text-zinc-400 font-mono">EST. 2026</span>
      </div>

      {/* Main Logo & Typography */}
      <div className="flex flex-col items-center text-center my-auto space-y-6">
        {/* Large Monolithic Badge */}
        <div className="relative flex items-center justify-center">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl border-2 border-white bg-black flex flex-col items-center justify-center shadow-[0_0_35px_rgba(255,255,255,0.15)]">
            <span className="text-5xl sm:text-6xl font-black tracking-tighter text-white font-mono leading-none">
              47
            </span>
          </div>
          <div className="absolute -bottom-2.5 px-3 py-0.5 bg-white text-black text-[10px] font-bold tracking-widest uppercase rounded">
            OFFICIAL
          </div>
        </div>

        <div className="space-y-2 pt-2">
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white uppercase">
            The 47
          </h1>
          <div className="flex items-center justify-center space-x-2">
            <span className="h-px w-6 bg-zinc-600" />
            <p className="text-sm sm:text-base font-medium tracking-wide text-zinc-300">
              by <span className="text-white font-semibold underline underline-offset-4 decoration-zinc-500">Ronak Suthar</span>
            </p>
            <span className="h-px w-6 bg-zinc-600" />
          </div>
          <p className="text-xs text-zinc-400 font-mono tracking-wide pt-1">
            Mobile Repair • Money Transfer • Accessories
          </p>
        </div>

        {/* Feature Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 max-w-xs pt-2">
          <span className="px-2.5 py-1 text-[11px] font-mono border border-zinc-800 bg-zinc-950 text-zinc-300 rounded">
            Cash In & Out
          </span>
          <span className="px-2.5 py-1 text-[11px] font-mono border border-zinc-800 bg-zinc-950 text-zinc-300 rounded">
            Instant Balances
          </span>
          <span className="px-2.5 py-1 text-[11px] font-mono border border-zinc-800 bg-zinc-950 text-zinc-300 rounded">
            WhatsApp Receipt
          </span>
        </div>
      </div>

      {/* Footer / Skip Action */}
      <div className="w-full max-w-sm pb-6 flex flex-col items-center space-y-3">
        <button
          onClick={handleManualDismiss}
          className="w-full py-3 px-4 bg-white text-black font-semibold text-xs tracking-wider uppercase rounded-lg hover:bg-zinc-200 active:scale-[0.99] transition flex items-center justify-center space-x-2 border border-white"
        >
          <span>Open Ledger</span>
          <ArrowRight className="w-4 h-4" />
        </button>
        <div className="flex items-center space-x-1.5 text-[11px] text-zinc-400 font-mono">
          <Smartphone className="w-3.5 h-3.5" />
          <span>Radhe Mobile Account Manager</span>
        </div>
      </div>
    </div>
  );
};
