import React, { useState } from 'react';
import {
  Search,
  X,
  Phone,
  MessageCircle,
  Edit2,
  Trash2,
  FileText,
  Wrench,
  Send,
  Headphones,
  Package,
  ArrowDownLeft,
  ArrowUpRight,
  Filter,
  ArrowUpDown,
} from 'lucide-react';
import { Transaction, TransactionType, FlowType } from '../types';
import { formatCurrency, formatDateDisplay, formatTimeDisplay, generateWhatsAppLink } from '../utils/formatters';

interface LedgerListProps {
  transactions: Transaction[];
  onEdit: (tx: Transaction) => void;
  onDelete: (id: string) => void;
  onViewReceipt: (tx: Transaction) => void;
  onOpenNewEntry: () => void;
}

export const LedgerList: React.FC<LedgerListProps> = ({
  transactions,
  onEdit,
  onDelete,
  onViewReceipt,
  onOpenNewEntry,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<TransactionType | 'ALL'>('ALL');
  const [selectedFlow, setSelectedFlow] = useState<FlowType | 'ALL'>('ALL');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc'>('date-desc');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Filter logic
  const filteredTransactions = transactions.filter((tx) => {
    // Search query matches customer name or mobile or notes
    const q = searchQuery.toLowerCase().trim();
    if (q) {
      const matchName = tx.customerName.toLowerCase().includes(q);
      const matchPhone = tx.mobileNumber.toLowerCase().includes(q);
      const matchNotes = (tx.notes || '').toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchNotes) return false;
    }

    // Type filter
    if (selectedType !== 'ALL' && tx.type !== selectedType) {
      return false;
    }

    // Flow filter
    if (selectedFlow !== 'ALL' && tx.flow !== selectedFlow) {
      return false;
    }

    return true;
  });

  // Sorting
  const sortedTransactions = [...filteredTransactions].sort((a, b) => {
    if (sortBy === 'date-desc') {
      const dateDiff = new Date(`${b.date}T${b.time || '00:00'}`).getTime() - new Date(`${a.date}T${a.time || '00:00'}`).getTime();
      return dateDiff !== 0 ? dateDiff : b.createdAt - a.createdAt;
    }
    if (sortBy === 'date-asc') {
      const dateDiff = new Date(`${a.date}T${a.time || '00:00'}`).getTime() - new Date(`${b.date}T${b.time || '00:00'}`).getTime();
      return dateDiff !== 0 ? dateDiff : a.createdAt - b.createdAt;
    }
    if (sortBy === 'amount-desc') {
      return b.amount - a.amount;
    }
    if (sortBy === 'amount-asc') {
      return a.amount - b.amount;
    }
    return 0;
  });

  // Group by date
  const groupedByDate: { [date: string]: Transaction[] } = {};
  sortedTransactions.forEach((tx) => {
    if (!groupedByDate[tx.date]) {
      groupedByDate[tx.date] = [];
    }
    groupedByDate[tx.date].push(tx);
  });

  const getCategoryIcon = (type: TransactionType) => {
    switch (type) {
      case 'Mobile Repair':
        return <Wrench className="w-3.5 h-3.5" />;
      case 'Money Transfer':
        return <Send className="w-3.5 h-3.5" />;
      case 'Accessories':
        return <Headphones className="w-3.5 h-3.5" />;
      case 'Other':
      default:
        return <Package className="w-3.5 h-3.5" />;
    }
  };

  const confirmDelete = (id: string) => {
    onDelete(id);
    setDeletingId(null);
  };

  return (
    <section className="space-y-4">
      {/* Search and Filters Header */}
      <div className="space-y-3">
        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search by customer name, mobile number, or remarks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-2.5 rounded-lg border border-zinc-800 bg-zinc-950 font-sans text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white focus:ring-1 focus:ring-white transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter controls row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          {/* Category tabs */}
          <div className="flex items-center space-x-1.5 overflow-x-auto py-0.5 scrollbar-none">
            {(['ALL', 'Mobile Repair', 'Money Transfer', 'Accessories', 'Other'] as const).map((cat) => {
              const isSelected = selectedType === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedType(cat)}
                  className={`px-2.5 py-1 text-xs font-mono rounded transition shrink-0 flex items-center gap-1 ${
                    isSelected
                      ? 'bg-white text-black font-semibold border border-white'
                      : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-900 hover:border-zinc-700'
                  }`}
                >
                  {cat !== 'ALL' && getCategoryIcon(cat as TransactionType)}
                  <span>{cat === 'ALL' ? 'All Types' : cat}</span>
                </button>
              );
            })}
          </div>

          {/* Secondary filter & Sort */}
          <div className="flex items-center space-x-2 shrink-0">
            {/* Flow Filter */}
            <div className="flex items-center border border-zinc-900 rounded bg-zinc-950 p-0.5 text-xs font-mono">
              <button
                onClick={() => setSelectedFlow('ALL')}
                className={`px-2 py-0.5 rounded transition ${
                  selectedFlow === 'ALL' ? 'bg-zinc-800 text-white font-semibold' : 'text-zinc-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedFlow('TAKEN')}
                className={`px-2 py-0.5 rounded transition flex items-center gap-1 ${
                  selectedFlow === 'TAKEN' ? 'bg-zinc-200 text-black font-bold' : 'text-zinc-400 hover:text-white'
                }`}
                title="Only Inflow (Taken)"
              >
                <ArrowDownLeft className="w-3 h-3" />
                <span>Taken</span>
              </button>
              <button
                onClick={() => setSelectedFlow('GIVEN')}
                className={`px-2 py-0.5 rounded transition flex items-center gap-1 ${
                  selectedFlow === 'GIVEN' ? 'bg-zinc-200 text-black font-bold' : 'text-zinc-400 hover:text-white'
                }`}
                title="Only Outflow (Given)"
              >
                <ArrowUpRight className="w-3 h-3" />
                <span>Given</span>
              </button>
            </div>

            {/* Sort toggle */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-2 py-1 text-xs font-mono border border-zinc-900 rounded bg-zinc-950 text-zinc-300 focus:outline-none focus:border-zinc-700"
            >
              <option value="date-desc">Newest First</option>
              <option value="date-asc">Oldest First</option>
              <option value="amount-desc">Highest Amount</option>
              <option value="amount-asc">Lowest Amount</option>
            </select>
          </div>
        </div>
      </div>

      {/* Record List Grouped by Date */}
      {Object.keys(groupedByDate).length === 0 ? (
        <div className="py-12 px-4 text-center border border-dashed border-zinc-800 rounded-xl bg-zinc-950/50 space-y-3">
          <div className="w-12 h-12 rounded-full border border-zinc-700 mx-auto flex items-center justify-center text-zinc-400 font-mono font-bold text-lg">
            47
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              No Ledger Records Found
            </h3>
            <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
              {searchQuery || selectedType !== 'ALL' || selectedFlow !== 'ALL'
                ? 'Try adjusting your search filters to find transactions.'
                : 'Start tracking daily mobile repairs, money transfers, and accessories sales.'}
            </p>
          </div>
          <div className="pt-2">
            {searchQuery || selectedType !== 'ALL' || selectedFlow !== 'ALL' ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedType('ALL');
                  setSelectedFlow('ALL');
                }}
                className="px-3 py-1.5 border border-zinc-700 rounded text-xs font-mono text-zinc-300 hover:text-white hover:border-white transition"
              >
                Clear Filters
              </button>
            ) : (
              <button
                onClick={onOpenNewEntry}
                className="px-4 py-2 bg-white text-black font-semibold text-xs tracking-wider uppercase font-mono rounded border border-white hover:bg-zinc-200 transition"
              >
                + Add First Transaction
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedByDate).map(([dateStr, items]) => {
            // Calculate daily subtotal
            const dayTaken = items.filter((i) => i.flow === 'TAKEN').reduce((s, i) => s + i.amount, 0);
            const dayGiven = items.filter((i) => i.flow === 'GIVEN').reduce((s, i) => s + i.amount, 0);
            const dayNet = dayTaken - dayGiven;

            return (
              <div key={dateStr} className="space-y-2">
                {/* Date Group Header */}
                <div className="flex items-center justify-between pb-1 border-b border-zinc-900 sticky top-14 bg-black/90 backdrop-blur py-1.5 z-10">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold font-mono uppercase tracking-wider text-white">
                      {formatDateDisplay(dateStr)}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-300">
                      ({items.length} {items.length === 1 ? 'item' : 'items'})
                    </span>
                  </div>
                  <div className="text-[11px] font-mono flex items-center space-x-2">
                    <span className="text-zinc-300">
                      Day Net:{' '}
                      <span className="font-bold text-white">
                        {dayNet >= 0 ? '+' : '-'}
                        {formatCurrency(Math.abs(dayNet))}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Transaction Cards List */}
                <div className="space-y-2">
                  {items.map((tx) => {
                    const isTaken = tx.flow === 'TAKEN';
                    const isDeletingThis = deletingId === tx.id;

                    return (
                      <div
                        key={tx.id}
                        className="p-3.5 rounded-xl border border-zinc-800/90 bg-zinc-950 hover:border-zinc-600 transition group relative"
                      >
                        <div className="flex items-start justify-between gap-3">
                          {/* Left: Customer, Service Type, Notes */}
                          <div className="space-y-1.5 min-w-0 flex-1">
                            <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                              {/* Flow Badge */}
                              <span
                                className={`text-[10px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded flex items-center gap-1 ${
                                  isTaken
                                    ? 'bg-white text-black'
                                    : 'border border-zinc-700 text-zinc-300 bg-black'
                                }`}
                              >
                                {isTaken ? (
                                  <>
                                    <ArrowDownLeft className="w-3 h-3 stroke-[2.5]" />
                                    <span>TAKEN</span>
                                  </>
                                ) : (
                                  <>
                                    <ArrowUpRight className="w-3 h-3 stroke-[2.5]" />
                                    <span>GIVEN</span>
                                  </>
                                )}
                              </span>

                              {/* Category Badge */}
                              <span className="text-[10px] font-mono border border-zinc-800 bg-black text-zinc-300 px-1.5 py-0.5 rounded flex items-center gap-1">
                                {getCategoryIcon(tx.type)}
                                <span>{tx.type}</span>
                              </span>

                              {/* Payment Method */}
                              {tx.paymentMethod && (
                                <span className="text-[10px] font-mono text-zinc-400">
                                  via {tx.paymentMethod}
                                </span>
                              )}

                              {/* Time */}
                              <span className="text-[10px] font-mono text-zinc-400">
                                • {formatTimeDisplay(tx.time)}
                              </span>
                            </div>

                            {/* Customer Name */}
                            <div className="flex items-center space-x-2">
                              <h4 className="text-sm sm:text-base font-bold text-white tracking-tight truncate">
                                {tx.customerName}
                              </h4>
                            </div>

                            {/* Mobile Phone & Quick Contact */}
                            {tx.mobileNumber && (
                              <div className="flex items-center space-x-2.5 text-xs font-mono text-zinc-400">
                                <a
                                  href={`tel:${tx.mobileNumber}`}
                                  className="hover:text-white flex items-center gap-1 transition"
                                  title="Call customer"
                                >
                                  <Phone className="w-3 h-3 text-zinc-300" />
                                  <span>{tx.mobileNumber}</span>
                                </a>

                                <a
                                  href={generateWhatsAppLink(tx)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-zinc-400 hover:text-white flex items-center gap-1 transition underline underline-offset-2"
                                  title="Send receipt on WhatsApp"
                                >
                                  <MessageCircle className="w-3 h-3 text-zinc-300" />
                                  <span>WhatsApp</span>
                                </a>
                              </div>
                            )}

                            {/* Notes / Details */}
                            {tx.notes && (
                              <p className="text-xs text-zinc-300 font-sans pt-0.5 bg-black/40 px-2 py-1 rounded border border-zinc-900 inline-block max-w-full break-words">
                                {tx.notes}
                              </p>
                            )}
                          </div>

                          {/* Right: Amount & Actions */}
                          <div className="flex flex-col items-end space-y-2 shrink-0">
                            {/* Amount */}
                            <div className="text-right">
                              <div
                                className={`text-base sm:text-lg font-black font-mono tracking-tight ${
                                  isTaken ? 'text-white' : 'text-zinc-300'
                                }`}
                              >
                                {isTaken ? '+' : '-'}
                                {formatCurrency(tx.amount)}
                              </div>
                              <span className="text-[10px] font-mono text-zinc-400 uppercase">
                                {isTaken ? 'Cash In' : 'Cash Out'}
                              </span>
                            </div>

                            {/* Actions Buttons */}
                            <div className="flex items-center space-x-1 pt-1">
                              <button
                                onClick={() => onViewReceipt(tx)}
                                title="View Thermal Receipt"
                                className="p-1.5 rounded border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 transition"
                              >
                                <FileText className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => onEdit(tx)}
                                title="Edit Entry"
                                className="p-1.5 rounded border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 transition"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => setDeletingId(tx.id)}
                                title="Delete Entry"
                                className="p-1.5 rounded border border-zinc-800 text-zinc-400 hover:text-red-400 hover:border-red-900 transition"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Inline Delete Confirmation */}
                        {isDeletingThis && (
                          <div className="mt-3 pt-3 border-t border-zinc-800 flex items-center justify-between gap-2 flex-wrap">
                            <span className="text-xs font-mono text-zinc-300">
                              Delete this entry permanently?
                            </span>
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => setDeletingId(null)}
                                className="px-2.5 py-1 text-xs font-mono border border-zinc-800 rounded text-zinc-400 hover:text-white"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => confirmDelete(tx.id)}
                                className="px-2.5 py-1 text-xs font-mono bg-white text-black font-bold rounded border border-white hover:bg-zinc-200"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
