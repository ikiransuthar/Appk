import React from 'react';
import { X, Wrench, Send, Headphones, Package, TrendingUp, BarChart2, Layers } from 'lucide-react';
import { Transaction, TransactionType } from '../types';
import { formatCurrency } from '../utils/formatters';

interface AnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
}

export const AnalyticsModal: React.FC<AnalyticsModalProps> = ({ isOpen, onClose, transactions }) => {
  if (!isOpen) return null;

  const totalCount = transactions.length;
  const totalTaken = transactions.filter((t) => t.flow === 'TAKEN').reduce((s, t) => s + t.amount, 0);
  const totalGiven = transactions.filter((t) => t.flow === 'GIVEN').reduce((s, t) => s + t.amount, 0);
  const netBalance = totalTaken - totalGiven;

  // Breakdown by category
  const categories: TransactionType[] = ['Mobile Repair', 'Money Transfer', 'Accessories', 'Other'];
  
  const categoryStats = categories.map((cat) => {
    const list = transactions.filter((t) => t.type === cat);
    const count = list.length;
    const taken = list.filter((t) => t.flow === 'TAKEN').reduce((s, t) => s + t.amount, 0);
    const given = list.filter((t) => t.flow === 'GIVEN').reduce((s, t) => s + t.amount, 0);
    const volume = list.reduce((s, t) => s + t.amount, 0);
    const percentOfTotal = totalTaken > 0 ? Math.round((taken / totalTaken) * 100) : 0;
    return {
      category: cat,
      count,
      taken,
      given,
      volume,
      percentOfTotal,
    };
  });

  const getCategoryIcon = (type: TransactionType) => {
    switch (type) {
      case 'Mobile Repair':
        return <Wrench className="w-4 h-4" />;
      case 'Money Transfer':
        return <Send className="w-4 h-4" />;
      case 'Accessories':
        return <Headphones className="w-4 h-4" />;
      case 'Other':
      default:
        return <Package className="w-4 h-4" />;
    }
  };

  const avgTicket = totalCount > 0 ? Math.round((totalTaken + totalGiven) / totalCount) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div 
        className="w-full max-w-lg bg-black border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-950">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded border border-white flex items-center justify-center font-mono font-bold text-xs bg-black text-white">
              47
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
                Business Intelligence & Breakdown
              </h2>
              <p className="text-[11px] font-mono text-zinc-400">
                Radhe Mobile • The 47 Ledger Overview
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto text-sm">
          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="p-2.5 rounded-lg border border-zinc-900 bg-zinc-950">
              <span className="text-[10px] font-mono text-zinc-400 block uppercase">Total Entries</span>
              <span className="text-lg font-bold font-mono text-white">{totalCount}</span>
            </div>
            <div className="p-2.5 rounded-lg border border-zinc-900 bg-zinc-950">
              <span className="text-[10px] font-mono text-zinc-400 block uppercase">Total Inflow</span>
              <span className="text-lg font-bold font-mono text-white">{formatCurrency(totalTaken)}</span>
            </div>
            <div className="p-2.5 rounded-lg border border-zinc-900 bg-zinc-950">
              <span className="text-[10px] font-mono text-zinc-400 block uppercase">Total Outflow</span>
              <span className="text-lg font-bold font-mono text-zinc-300">{formatCurrency(totalGiven)}</span>
            </div>
            <div className="p-2.5 rounded-lg border border-zinc-900 bg-zinc-950">
              <span className="text-[10px] font-mono text-zinc-400 block uppercase">Avg Ticket</span>
              <span className="text-lg font-bold font-mono text-white">{formatCurrency(avgTicket)}</span>
            </div>
          </div>

          {/* Category Breakdown */}
          <div className="space-y-3 pt-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" />
              Category Distribution
            </span>

            <div className="space-y-2.5">
              {categoryStats.map((item) => (
                <div
                  key={item.category}
                  className="p-3 rounded-xl border border-zinc-800 bg-zinc-950/80 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="p-1.5 rounded border border-zinc-800 bg-black text-white">
                        {getCategoryIcon(item.category)}
                      </div>
                      <div>
                        <div className="font-mono text-xs font-bold text-white">{item.category}</div>
                        <div className="text-[10px] text-zinc-400 font-mono">
                          {item.count} {item.count === 1 ? 'transaction' : 'transactions'}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-sm font-bold text-white">
                        {formatCurrency(item.taken)}
                      </div>
                      <div className="text-[10px] font-mono text-zinc-400">
                        Taken (+ Inflow)
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar in monochrome */}
                  <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden flex">
                    <div
                      className="bg-white h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, item.percentOfTotal)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                    <span>Contribution to Inflow: {item.percentOfTotal}%</span>
                    {item.given > 0 && <span>Outflow / Disbursed: {formatCurrency(item.given)}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Net Flow Analysis */}
          <div className="p-3.5 rounded-xl border border-zinc-800 bg-zinc-950 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-mono uppercase text-zinc-400 tracking-wider">
                Radhe Mobile Till Status
              </span>
              <div className="font-bold text-white font-mono text-sm">
                Net Business Surplus: {formatCurrency(netBalance)}
              </div>
            </div>
            <div className="px-2.5 py-1 bg-white text-black font-mono font-bold text-xs uppercase tracking-wider rounded border border-white">
              {netBalance >= 0 ? 'HEALTHY' : 'PENDING'}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-zinc-800 bg-zinc-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-zinc-800 text-zinc-300 hover:text-white font-mono text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
