import React, { useState } from 'react';
import { X, Printer, MessageCircle, Copy, Check, Smartphone } from 'lucide-react';
import { Transaction } from '../types';
import { formatCurrency, formatDateDisplay, formatTimeDisplay, generateWhatsAppLink } from '../utils/formatters';

interface ReceiptModalProps {
  transaction: Transaction | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ transaction, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!transaction) return null;

  const isTaken = transaction.flow === 'TAKEN';
  const flowLabel = isTaken ? 'Amount Received' : 'Amount Paid / Transferred';

  const receiptText = `RADHE MOBILE — THE 47 LEDGER\n` +
    `Managed by: Ronak Suthar\n` +
    `--------------------------------\n` +
    `Receipt ID: #${transaction.id}\n` +
    `Date: ${formatDateDisplay(transaction.date)} at ${formatTimeDisplay(transaction.time)}\n` +
    `Customer: ${transaction.customerName}\n` +
    (transaction.mobileNumber ? `Phone: ${transaction.mobileNumber}\n` : '') +
    `Category: ${transaction.type}\n` +
    `Nature: ${flowLabel}\n` +
    `Amount: ${formatCurrency(transaction.amount)}\n` +
    (transaction.paymentMethod ? `Payment: ${transaction.paymentMethod}\n` : '') +
    (transaction.notes ? `Details: ${transaction.notes}\n` : '') +
    `--------------------------------\n` +
    `Thank you for trusting Radhe Mobile!`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(receiptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div 
        className="w-full max-w-md bg-black border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-zinc-950 no-print">
          <span className="text-xs font-mono uppercase tracking-wider text-zinc-400">Digital Voucher / Receipt</span>
          <button
            onClick={onClose}
            className="p-1 rounded-lg border border-zinc-800 text-zinc-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Thermal Receipt Aesthetic Container */}
        <div className="p-6 bg-black text-white font-mono text-xs space-y-4">
          {/* Header Branding */}
          <div className="text-center space-y-1 border-b border-dashed border-zinc-700 pb-4">
            <div className="w-10 h-10 mx-auto rounded-lg border border-white flex items-center justify-center text-lg font-black bg-black text-white">
              47
            </div>
            <h2 className="text-base font-black tracking-wider uppercase pt-1">
              RADHE MOBILE
            </h2>
            <p className="text-[11px] text-zinc-400">
              The 47 Ledger • Managed by Ronak Suthar
            </p>
            <p className="text-[10px] text-zinc-400 tracking-wider">
              Mobile Repair • Money Transfer • Accessories
            </p>
          </div>

          {/* Metadata */}
          <div className="space-y-1.5 py-1 border-b border-dashed border-zinc-800 pb-3">
            <div className="flex justify-between">
              <span className="text-zinc-400">Ref ID:</span>
              <span className="font-semibold text-white">#{transaction.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-400">Date:</span>
              <span className="text-white">{formatDateDisplay(transaction.date)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-400">Time:</span>
              <span className="text-white">{formatTimeDisplay(transaction.time)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-400">Payment:</span>
              <span className="text-white">{transaction.paymentMethod || 'Cash'}</span>
            </div>
          </div>

          {/* Customer & Item details */}
          <div className="space-y-1.5 border-b border-dashed border-zinc-800 pb-3">
            <div className="flex justify-between">
              <span className="text-zinc-400">Customer:</span>
              <span className="font-bold text-white uppercase">{transaction.customerName}</span>
            </div>
            {transaction.mobileNumber && (
              <div className="flex justify-between">
                <span className="text-zinc-400">Mobile:</span>
                <span className="text-white">{transaction.mobileNumber}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-zinc-400">Category:</span>
              <span className="text-white font-semibold">{transaction.type}</span>
            </div>
            {transaction.notes && (
              <div className="pt-1 text-zinc-300">
                <span className="text-zinc-400 block text-[10px] uppercase">Notes:</span>
                <p className="font-sans text-xs mt-0.5 bg-zinc-950 p-2 rounded border border-zinc-800">
                  {transaction.notes}
                </p>
              </div>
            )}
          </div>

          {/* Total Amount Block */}
          <div className="py-2 border-b border-dashed border-zinc-700 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-zinc-400 block">
                {flowLabel}
              </span>
              <span className="text-sm font-bold uppercase text-white">Total Amount</span>
            </div>
            <div className="text-xl sm:text-2xl font-black text-white">
              {formatCurrency(transaction.amount)}
            </div>
          </div>

          {/* Footer note */}
          <div className="text-center text-[10px] text-zinc-400 space-y-1 pt-1">
            <p>Thank you for your visit!</p>
            <p className="tracking-widest uppercase">The 47 • Radhe Mobile</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3.5 border-t border-zinc-800 bg-zinc-950 flex items-center justify-between gap-2 no-print">
          <button
            onClick={copyToClipboard}
            className="px-3 py-2 rounded-lg border border-zinc-800 bg-black text-xs font-mono text-zinc-300 hover:text-white hover:border-zinc-700 transition flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-2 rounded-lg border border-zinc-800 bg-black text-xs font-mono text-zinc-300 hover:text-white hover:border-zinc-700 transition flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            {transaction.mobileNumber && (
              <a
                href={generateWhatsAppLink(transaction)}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 rounded-lg bg-white text-black font-bold text-xs font-mono hover:bg-zinc-200 transition flex items-center gap-1.5 border border-white"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
