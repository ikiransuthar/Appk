import React, { useState, useEffect } from 'react';
import { X, ArrowDownLeft, ArrowUpRight, Check, Clock, Calendar, Smartphone, Plus } from 'lucide-react';
import { Transaction, TransactionType, FlowType } from '../types';

interface TransactionFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Omit<Transaction, 'id' | 'createdAt'> & { id?: string }) => void;
  editingTransaction?: Transaction | null;
}

export const TransactionFormModal: React.FC<TransactionFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingTransaction,
}) => {
  const getTodayDate = () => new Date().toISOString().split('T')[0];
  const getCurrentTime = () => {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  const [customerName, setCustomerName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [type, setType] = useState<TransactionType>('Mobile Repair');
  const [flow, setFlow] = useState<FlowType>('TAKEN');
  const [amount, setAmount] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDate());
  const [time, setTime] = useState<string>(getCurrentTime());
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'UPI' | 'Bank Transfer' | 'Credit'>('Cash');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (editingTransaction) {
      setCustomerName(editingTransaction.customerName);
      setMobileNumber(editingTransaction.mobileNumber);
      setType(editingTransaction.type);
      setFlow(editingTransaction.flow);
      setAmount(editingTransaction.amount.toString());
      setDate(editingTransaction.date);
      setTime(editingTransaction.time);
      setPaymentMethod(editingTransaction.paymentMethod || 'Cash');
      setNotes(editingTransaction.notes || '');
      setErrors({});
    } else {
      // Reset form to defaults
      setCustomerName('');
      setMobileNumber('');
      setType('Mobile Repair');
      setFlow('TAKEN');
      setAmount('');
      setDate(getTodayDate());
      setTime(getCurrentTime());
      setPaymentMethod('Cash');
      setNotes('');
      setErrors({});
    }
  }, [editingTransaction, isOpen]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const errs: { [key: string]: string } = {};
    if (!customerName.trim()) {
      errs.customerName = 'Customer name is required';
    }
    const numAmount = parseFloat(amount);
    if (!amount || isNaN(numAmount) || numAmount <= 0) {
      errs.amount = 'Enter a valid amount greater than 0';
    }
    if (!date) {
      errs.date = 'Date is required';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (keepOpen = false) => {
    if (!validate()) return;

    onSave({
      id: editingTransaction ? editingTransaction.id : undefined,
      customerName: customerName.trim(),
      mobileNumber: mobileNumber.trim(),
      type,
      flow,
      amount: parseFloat(amount),
      date,
      time: time || getCurrentTime(),
      paymentMethod,
      notes: notes.trim(),
    });

    if (keepOpen) {
      // Reset fields for the next entry while keeping date & flow
      setCustomerName('');
      setMobileNumber('');
      setAmount('');
      setNotes('');
      setTime(getCurrentTime());
      setErrors({});
    } else {
      onClose();
    }
  };

  const setNow = () => {
    setDate(getTodayDate());
    setTime(getCurrentTime());
  };

  const addAmountPreset = (increment: number) => {
    const current = parseFloat(amount) || 0;
    setAmount(String(current + increment));
  };

  // Quick chips depending on transaction type
  const quickNotesByType: Record<TransactionType, string[]> = {
    'Mobile Repair': ['Display / Combo', 'Original Battery', 'Charging Jack', 'Tempered Glass', 'Speaker / Mic', 'Water Damage', 'Software'],
    'Money Transfer': ['SBI Account', 'Bank of Baroda', 'HDFC Bank', 'Cash Deposit', 'IMPS / RTGS', 'Commission Added'],
    'Accessories': ['Back Cover', 'Tempered Glass', 'Fast Charger 33W', 'Type-C Cable', 'Earphones', 'Neckband'],
    'Other': ['SIM Card / Recharge', 'Photo Print / Lamination', 'General Sale', 'Customer Credit'],
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div 
        className="w-full max-w-lg bg-black border-t sm:border border-zinc-800 sm:rounded-2xl shadow-2xl flex flex-col max-h-[92vh] sm:max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-950">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded border border-white flex items-center justify-center font-mono font-bold text-xs bg-black text-white">
              47
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
                {editingTransaction ? 'Edit Transaction' : 'New Transaction Entry'}
              </h2>
              <p className="text-[11px] font-mono text-zinc-400">
                Radhe Mobile Ledger • {editingTransaction ? 'Updating Record' : 'Record Book'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4 overflow-y-auto text-sm">
          {/* Nature / Flow: TAKEN vs GIVEN */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Transaction Nature (Given / Taken) *
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setFlow('TAKEN')}
                className={`py-3 px-3 rounded-lg border font-mono text-xs flex items-center justify-center gap-2 transition ${
                  flow === 'TAKEN'
                    ? 'bg-white text-black font-bold border-white shadow-sm'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
                <div className="text-left">
                  <div className="leading-tight">AMOUNT TAKEN</div>
                  <div className={`text-[10px] ${flow === 'TAKEN' ? 'text-zinc-700' : 'text-zinc-500'}`}>
                    Received from Customer
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFlow('GIVEN')}
                className={`py-3 px-3 rounded-lg border font-mono text-xs flex items-center justify-center gap-2 transition ${
                  flow === 'GIVEN'
                    ? 'bg-white text-black font-bold border-white shadow-sm'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                <div className="text-left">
                  <div className="leading-tight">AMOUNT GIVEN</div>
                  <div className={`text-[10px] ${flow === 'GIVEN' ? 'text-zinc-700' : 'text-zinc-500'}`}>
                    Paid / Sent / Udhaar
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Amount input with large display & quick increment chips */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium flex items-center justify-between">
              <span>Amount (₹ INR) *</span>
              {errors.amount && <span className="text-red-400 font-sans normal-case text-xs">{errors.amount}</span>}
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-bold text-lg text-zinc-400">
                ₹
              </span>
              <input
                type="number"
                step="any"
                min="0"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`w-full pl-8 pr-4 py-2.5 rounded-lg border bg-zinc-950 font-mono text-xl sm:text-2xl font-bold text-white placeholder-zinc-700 focus:outline-none focus:ring-1 focus:ring-white ${
                  errors.amount ? 'border-red-500' : 'border-zinc-800 focus:border-white'
                }`}
              />
            </div>
            {/* Quick add chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pt-1 scrollbar-none">
              <span className="text-[10px] font-mono text-zinc-400 uppercase">Quick:</span>
              {[100, 200, 500, 1000, 2000, 5000].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => addAmountPreset(val)}
                  className="px-2 py-0.5 text-[11px] font-mono border border-zinc-800 rounded bg-zinc-900 text-zinc-300 hover:text-white hover:border-zinc-600 transition shrink-0"
                >
                  +{val}
                </button>
              ))}
              {amount && (
                <button
                  type="button"
                  onClick={() => setAmount('')}
                  className="px-2 py-0.5 text-[10px] font-mono border border-zinc-800 rounded text-zinc-400 hover:text-white transition shrink-0"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Customer Name & Mobile Number */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium flex items-center justify-between">
                <span>Customer Name *</span>
                {errors.customerName && <span className="text-red-400 font-sans normal-case text-xs">{errors.customerName}</span>}
              </label>
              <input
                type="text"
                placeholder="e.g. Ramesh Patel"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className={`w-full px-3 py-2 rounded-lg border bg-zinc-950 font-sans text-sm text-white placeholder-zinc-600 focus:outline-none focus:ring-1 focus:ring-white ${
                  errors.customerName ? 'border-red-500' : 'border-zinc-800 focus:border-white'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
                Mobile Number
              </label>
              <input
                type="tel"
                placeholder="10-digit number"
                maxLength={10}
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                className="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 font-mono text-sm text-white placeholder-zinc-600 focus:outline-none focus:ring-1 focus:ring-white focus:border-white"
              />
            </div>
          </div>

          {/* Transaction Type (Dropdown requirement: Mobile Repair, Money Transfer, Accessories, Other) */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Transaction Type *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['Mobile Repair', 'Money Transfer', 'Accessories', 'Other'] as TransactionType[]).map((t) => {
                const isSelected = type === t;
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setType(t)}
                    className={`py-2 px-2 text-xs font-mono rounded-lg border text-center transition ${
                      isSelected
                        ? 'bg-white text-black font-bold border-white'
                        : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>

            {/* Quick preset chips for remarks based on selected type */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-[10px] font-mono text-zinc-400 uppercase">Tags:</span>
              {quickNotesByType[type].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => {
                    const current = notes ? `${notes}, ${tag}` : tag;
                    setNotes(current);
                  }}
                  className="px-2 py-0.5 text-[10px] font-mono border border-zinc-900 rounded bg-zinc-950 text-zinc-400 hover:text-white hover:border-zinc-700 transition"
                >
                  +{tag}
                </button>
              ))}
            </div>
          </div>

          {/* Date & Time with "Now" button */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
                  Date *
                </label>
                <button
                  type="button"
                  onClick={setNow}
                  className="text-[10px] font-mono text-zinc-300 hover:text-white flex items-center gap-1 underline underline-offset-2"
                >
                  <Clock className="w-3 h-3" />
                  Today & Now
                </button>
              </div>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 font-mono text-sm text-white focus:outline-none focus:ring-1 focus:ring-white focus:border-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
                Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 font-mono text-sm text-white focus:outline-none focus:ring-1 focus:ring-white focus:border-white"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Payment Mode
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(['Cash', 'UPI', 'Bank Transfer', 'Credit'] as const).map((method) => {
                const isSelected = paymentMethod === method;
                return (
                  <button
                    key={method}
                    type="button"
                    onClick={() => setPaymentMethod(method)}
                    className={`py-1.5 px-2 text-[11px] font-mono rounded border text-center transition ${
                      isSelected
                        ? 'bg-zinc-200 text-black font-semibold border-white'
                        : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {method}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notes / Details */}
          <div className="space-y-1">
            <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Notes / Device Model / UTR / Remarks
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Redmi Note 11 screen combo + 1 month touch warranty"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 font-sans text-sm text-white placeholder-zinc-600 focus:outline-none focus:ring-1 focus:ring-white focus:border-white"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-4 border-t border-zinc-800 bg-zinc-950 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2.5 rounded-lg border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 font-mono text-xs transition"
          >
            Cancel
          </button>

          <div className="w-full sm:w-auto flex items-center gap-2">
            {!editingTransaction && (
              <button
                type="button"
                onClick={() => handleSubmit(true)}
                className="w-1/2 sm:w-auto px-4 py-2.5 rounded-lg border border-zinc-700 bg-zinc-900 text-white font-mono text-xs hover:bg-zinc-800 transition flex items-center justify-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Save & New</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => handleSubmit(false)}
              className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-white text-black font-bold font-mono text-xs tracking-wider uppercase hover:bg-zinc-200 active:scale-95 transition flex items-center justify-center gap-2 border border-white shadow"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>{editingTransaction ? 'Update Entry' : 'Save Entry'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
