import React from 'react';
import { Plus, Download, BarChart3, Smartphone, Printer, RefreshCw } from 'lucide-react';

interface HeaderProps {
  totalCount: number;
  onOpenNewEntry: () => void;
  onOpenExport: () => void;
  onOpenAnalytics: () => void;
  onPrint: () => void;
  onReplaySplash: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalCount,
  onOpenNewEntry,
  onOpenExport,
  onOpenAnalytics,
  onPrint,
  onReplaySplash,
}) => {
  const currentDate = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return (
    <header className="border-b border-zinc-800 bg-black/95 backdrop-blur sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 py-3 sm:py-4">
        {/* Top bar with prominent branding: The 47 by Ronak Suthar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start justify-between sm:justify-start gap-3">
            <button
              onClick={onReplaySplash}
              title="Click to view Splash Screen & About"
              className="flex items-center gap-3 group text-left cursor-pointer focus:outline-none"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg border border-white bg-black flex items-center justify-center font-mono font-bold text-lg text-white group-hover:bg-white group-hover:text-black transition">
                47
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white leading-tight">
                    The 47 <span className="font-normal text-zinc-300 text-sm sm:text-base">by Ronak Suthar</span>
                  </h1>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-300 flex items-center gap-1 font-medium">
                    <Smartphone className="w-3 h-3 text-zinc-400" />
                    Radhe Mobile Ledger
                  </span>
                  <span className="text-zinc-500">•</span>
                  <span className="text-[11px] font-mono text-zinc-400">
                    {totalCount} {totalCount === 1 ? 'Entry' : 'Entries'}
                  </span>
                </div>
              </div>
            </button>

            {/* Mobile quick add button */}
            <div className="flex sm:hidden items-center gap-1.5">
              <button
                onClick={onOpenNewEntry}
                className="px-3 py-2 bg-white text-black font-semibold text-xs tracking-wider uppercase rounded-md border border-white active:scale-95 transition flex items-center gap-1 shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Entry</span>
              </button>
            </div>
          </div>

          {/* Action buttons and live date for desktop/tablet */}
          <div className="flex items-center justify-between sm:justify-end gap-2 pt-1 sm:pt-0 border-t border-zinc-900 sm:border-0">
            <div className="text-[11px] font-mono text-zinc-400 hidden md:block px-2.5 py-1.5 border border-zinc-900 rounded bg-zinc-950">
              {currentDate}
            </div>

            <button
              onClick={onOpenAnalytics}
              title="View Business Breakdown"
              className="p-2 sm:px-3 sm:py-1.5 text-xs font-mono border border-zinc-800 rounded bg-zinc-950 hover:bg-zinc-900 hover:border-zinc-700 text-zinc-200 transition flex items-center gap-1.5"
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Analytics</span>
            </button>

            <button
              onClick={onPrint}
              title="Print Today's Ledger Sheet"
              className="p-2 sm:px-3 sm:py-1.5 text-xs font-mono border border-zinc-800 rounded bg-zinc-950 hover:bg-zinc-900 hover:border-zinc-700 text-zinc-200 transition flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print</span>
            </button>

            <button
              onClick={onOpenExport}
              title="Export CSV & Backup"
              className="p-2 sm:px-3 sm:py-1.5 text-xs font-mono border border-zinc-800 rounded bg-zinc-950 hover:bg-zinc-900 hover:border-zinc-700 text-zinc-200 transition flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export</span>
            </button>

            <button
              onClick={onOpenNewEntry}
              className="hidden sm:flex px-3.5 py-1.5 bg-white text-black font-semibold text-xs tracking-wider uppercase rounded border border-white hover:bg-zinc-200 active:scale-95 transition items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>New Transaction</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
