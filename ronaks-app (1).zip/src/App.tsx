/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Plus, CheckCircle2, Smartphone, Shield, ArrowUp } from 'lucide-react';
import { Transaction, TimeFilter } from './types';
import { getInitialTransactions } from './data/seedData';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { SummaryCards } from './components/SummaryCards';
import { LedgerList } from './components/LedgerList';
import { TransactionFormModal } from './components/TransactionFormModal';
import { ReceiptModal } from './components/ReceiptModal';
import { ExportModal } from './components/ExportModal';
import { AnalyticsModal } from './components/AnalyticsModal';
import { formatCurrency, formatDateDisplay } from './utils/formatters';

const STORAGE_KEY = 'the_47_radhe_mobile_ledger_v1';

export default function App() {
  // Splash screen state
  const [showSplash, setShowSplash] = useState(true);

  // Transactions state loaded from localStorage or initial seed
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to parse localStorage transactions', e);
    }
    return getInitialTransactions();
  });

  // Time filter for summary cards: today, yesterday, week, month, all
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('all');

  // Modals state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [viewingReceipt, setViewingReceipt] = useState<Transaction | null>(null);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync transactions to localStorage whenever changed
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  }, [transactions]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Filter transactions based on selected time filter for summary calculations
  const filteredForSummary = useMemo(() => {
    if (timeFilter === 'all') return transactions;

    const today = new Date();
    const formatYMD = (d: Date) => d.toISOString().split('T')[0];
    const todayStr = formatYMD(today);

    const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
    const yesterdayStr = formatYMD(yesterday);

    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

    return transactions.filter((tx) => {
      if (timeFilter === 'today') {
        return tx.date === todayStr;
      }
      if (timeFilter === 'yesterday') {
        return tx.date === yesterdayStr;
      }
      if (timeFilter === 'week') {
        const txDate = new Date(tx.date);
        return txDate >= sevenDaysAgo;
      }
      if (timeFilter === 'month') {
        const txDate = new Date(tx.date);
        return txDate >= monthStart;
      }
      return true;
    });
  }, [transactions, timeFilter]);

  // Aggregate totals
  const totalTaken = useMemo(() => {
    return filteredForSummary
      .filter((t) => t.flow === 'TAKEN')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredForSummary]);

  const totalGiven = useMemo(() => {
    return filteredForSummary
      .filter((t) => t.flow === 'GIVEN')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredForSummary]);

  const netBalance = totalTaken - totalGiven;

  // Add or update transaction handler
  const handleSaveTransaction = (
    data: Omit<Transaction, 'id' | 'createdAt'> & { id?: string }
  ) => {
    if (data.id) {
      // Update
      setTransactions((prev) =>
        prev.map((item) =>
          item.id === data.id
            ? { ...item, ...data, id: data.id }
            : item
        )
      );
      showToast('Record updated successfully');
    } else {
      // Create new
      const newTx: Transaction = {
        ...data,
        id: `tx-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 5)}`,
        createdAt: Date.now(),
      };
      setTransactions((prev) => [newTx, ...prev]);
      showToast(`Added ₹${data.amount} for ${data.customerName}`);
    }
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((item) => item.id !== id));
    showToast('Record removed from ledger');
  };

  const handleOpenEdit = (tx: Transaction) => {
    setEditingTransaction(tx);
    setIsFormOpen(true);
  };

  const handleOpenNewEntry = () => {
    setEditingTransaction(null);
    setIsFormOpen(true);
  };

  const handleImportData = (newData: Transaction[]) => {
    setTransactions(newData);
    showToast(`Restored ${newData.length} entries`);
  };

  const handleClearAll = () => {
    setTransactions([]);
    showToast('All ledger records cleared');
  };

  const handleResetDemo = () => {
    const seed = getInitialTransactions();
    setTransactions(seed);
    showToast('Reset to demo records');
  };

  const handlePrintStatement = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-white selection:text-black flex flex-col font-sans">
      {/* 1. Splash Screen on first load / manual replay */}
      {showSplash && <SplashScreen onDismiss={() => setShowSplash(false)} />}

      {/* 2. Top Header with prominent "The 47 by Ronak Suthar" */}
      <Header
        totalCount={transactions.length}
        onOpenNewEntry={handleOpenNewEntry}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenAnalytics={() => setIsAnalyticsOpen(true)}
        onPrint={handlePrintStatement}
        onReplaySplash={() => setShowSplash(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-5 space-y-6">
        {/* Prominent Banner Headline for Radhe Mobile */}
        <section className="border border-zinc-800 rounded-xl p-4 sm:p-5 bg-zinc-950/60 relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[10px] font-mono tracking-widest uppercase bg-white text-black font-bold rounded">
                  OFFICIAL LEDGER
                </span>
                <span className="text-xs font-mono text-zinc-300">Radhe Mobile Store</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase">
                The 47 <span className="font-medium text-zinc-300 text-base sm:text-lg">by Ronak Suthar</span>
              </h2>
              <p className="text-xs text-zinc-300 font-mono">
                Daily business ledger & account manager for Mobile Repair, Money Transfer, and Accessories.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1 sm:pt-0">
              <button
                onClick={handleOpenNewEntry}
                className="w-full sm:w-auto px-4 py-2.5 bg-white text-black font-bold text-xs tracking-wider uppercase font-mono rounded-lg border border-white hover:bg-zinc-200 active:scale-95 transition flex items-center justify-center gap-2 shadow-sm"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>+ Add Transaction</span>
              </button>
            </div>
          </div>
        </section>

        {/* 3. Summary Cards: Total Given, Total Taken, Net Balance */}
        <SummaryCards
          totalTaken={totalTaken}
          totalGiven={totalGiven}
          netBalance={netBalance}
          activeFilter={timeFilter}
          onFilterChange={setTimeFilter}
          filteredCount={filteredForSummary.length}
        />

        {/* 4. Ledger / Records List */}
        <LedgerList
          transactions={transactions}
          onEdit={handleOpenEdit}
          onDelete={handleDeleteTransaction}
          onViewReceipt={(tx) => setViewingReceipt(tx)}
          onOpenNewEntry={handleOpenNewEntry}
        />
      </main>

      {/* Floating Action Button for Mobile */}
      <div className="fixed bottom-5 right-5 sm:hidden z-20">
        <button
          onClick={handleOpenNewEntry}
          className="w-13 h-13 rounded-full bg-white text-black shadow-[0_4px_20px_rgba(255,255,255,0.3)] flex items-center justify-center border-2 border-white active:scale-90 transition"
          aria-label="Add transaction"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-zinc-900 border border-white text-white font-mono text-xs shadow-2xl animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Modals */}
      <TransactionFormModal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingTransaction(null);
        }}
        onSave={handleSaveTransaction}
        editingTransaction={editingTransaction}
      />

      <ReceiptModal
        transaction={viewingReceipt}
        onClose={() => setViewingReceipt(null)}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        transactions={transactions}
        onImportData={handleImportData}
        onClearAll={handleClearAll}
        onResetDemo={handleResetDemo}
      />

      <AnalyticsModal
        isOpen={isAnalyticsOpen}
        onClose={() => setIsAnalyticsOpen(false)}
        transactions={transactions}
      />

      {/* Footer Branding */}
      <footer className="border-t border-zinc-900 py-6 px-4 text-center mt-12 bg-black text-xs font-mono text-zinc-400 no-print space-y-2">
        <div className="flex items-center justify-center space-x-2">
          <span className="font-bold text-white uppercase">The 47</span>
          <span>•</span>
          <span className="text-zinc-300">Managed by Ronak Suthar</span>
          <span>•</span>
          <span>Radhe Mobile Ledger</span>
        </div>
        <p className="text-[11px] text-zinc-400">
          Strict Monochrome Dark Edition • Local Storage Persisted
        </p>
      </footer>
    </div>
  );
}
