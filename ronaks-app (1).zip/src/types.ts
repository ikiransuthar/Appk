export type TransactionType = 'Mobile Repair' | 'Money Transfer' | 'Accessories' | 'Other';

export type FlowType = 'TAKEN' | 'GIVEN'; // TAKEN = Inflow (Money received from customer), GIVEN = Outflow (Money given to customer / transfer sent)

export interface Transaction {
  id: string;
  customerName: string;
  mobileNumber: string;
  type: TransactionType;
  flow: FlowType;
  amount: number;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  notes?: string;
  paymentMethod?: 'Cash' | 'UPI' | 'Bank Transfer' | 'Credit';
  createdAt: number;
}

export type TimeFilter = 'all' | 'today' | 'yesterday' | 'week' | 'month';
