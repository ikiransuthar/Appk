import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Transaction } from '../types';
import { transactionsToCSV } from './csv';

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatDateDisplay = (dateStr: string): string => {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const targetDate = new Date(year, month - 1, day);
  
  const today = new Date();
  const todayYMD = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const targetYMD = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate()).getTime();

  const diffDays = Math.round((todayYMD - targetYMD) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';

  return targetDate.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

export const formatTimeDisplay = (timeStr: string): string => {
  if (!timeStr) return '';
  const [hours, minutes] = timeStr.split(':');
  const h = parseInt(hours, 10);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const displayH = h % 12 || 12;
  return `${displayH}:${minutes} ${ampm}`;
};

export const generateWhatsAppLink = (tx: Transaction): string => {
  const cleanPhone = tx.mobileNumber.replace(/\D/g, '');
  const phoneWithCode = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
  
  const flowText = tx.flow === 'TAKEN' ? 'Received' : 'Paid / Transferred';
  const message = `*Radhe Mobile — The 47 Ledger Receipt*\n` +
    `--------------------------------\n` +
    `*Customer:* ${tx.customerName}\n` +
    `*Service / Type:* ${tx.type}\n` +
    `*Amount:* ${formatCurrency(tx.amount)} (${flowText})\n` +
    `*Date:* ${formatDateDisplay(tx.date)} at ${formatTimeDisplay(tx.time)}\n` +
    (tx.notes ? `*Notes:* ${tx.notes}\n` : '') +
    `--------------------------------\n` +
    `Thank you for your business!\n` +
    `*Radhe Mobile* • Managed by Ronak Suthar`;

  return `https://wa.me/${phoneWithCode}?text=${encodeURIComponent(message)}`;
};

/**
 * Saves a text file. In the Android app (WebView) normal <a download> links do not work,
 * so the file is written to the app cache and the Android share sheet is opened
 * (Save to Drive / Files, WhatsApp, Gmail, Excel...). In a browser it downloads normally.
 */
const saveFile = async (fileName: string, content: string, mimeType: string): Promise<void> => {
  if (Capacitor.isNativePlatform()) {
    const written = await Filesystem.writeFile({
      path: fileName,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });
    try {
      await Share.share({
        title: fileName,
        dialogTitle: 'Save / share ledger file',
        url: written.uri,
      });
    } catch (err) {
      const message = String((err as { message?: string } | null)?.message ?? err).toLowerCase();
      if (message.includes('cancel')) return; // user closed the share sheet
      throw err;
    }
    return;
  }

  const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

const todayStamp = (): string => new Date().toISOString().split('T')[0];

export const exportToCSV = async (transactions: Transaction[]): Promise<void> => {
  await saveFile(`Radhe_Mobile_The47_Ledger_${todayStamp()}.csv`, transactionsToCSV(transactions), 'text/csv');
};

export const exportToJSON = async (transactions: Transaction[]): Promise<void> => {
  await saveFile(`The47_RadheMobile_Backup_${todayStamp()}.json`, JSON.stringify(transactions, null, 2), 'application/json');
};
