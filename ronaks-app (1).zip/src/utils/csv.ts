import { Transaction, TransactionType, FlowType } from '../types';

const TYPES: TransactionType[] = ['Mobile Repair', 'Money Transfer', 'Accessories', 'Other'];
const METHODS = ['Cash', 'UPI', 'Bank Transfer', 'Credit'] as const;

const HEADERS = [
  'ID',
  'Date',
  'Time',
  'Customer Name',
  'Mobile Number',
  'Category',
  'Flow',
  'Amount (INR)',
  'Payment Mode',
  'Notes',
];

const quote = (value: string | number): string => `"${String(value).replace(/"/g, '""')}"`;

/** Builds the ledger CSV text (UTF-8 BOM added so Excel shows ₹ and Gujarati/Hindi names correctly). */
export const transactionsToCSV = (transactions: Transaction[]): string => {
  const rows = transactions.map((t) =>
    [
      quote(t.id),
      quote(t.date),
      quote(t.time),
      quote(t.customerName),
      quote(t.mobileNumber),
      quote(t.type),
      quote(t.flow),
      t.amount,
      quote(t.paymentMethod || 'Cash'),
      quote(t.notes || ''),
    ].join(',')
  );
  return '\uFEFF' + [HEADERS.join(','), ...rows].join('\r\n');
};

const parseRows = (text: string, delimiter: string): string[][] => {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === delimiter) {
      row.push(field);
      field = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field);
      field = '';
      rows.push(row);
      row = [];
    } else {
      field += c;
    }
  }
  if (field !== '' || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.some((f) => f.trim() !== ''));
};

const pad = (n: number | string, len = 2): string => String(n).padStart(len, '0');

const normalizeDate = (raw: string): string | null => {
  const v = raw.trim();
  let m = v.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (m) return `${m[1]}-${pad(m[2])}-${pad(m[3])}`;
  m = v.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
  if (m) return `${m[3]}-${pad(m[2])}-${pad(m[1])}`; // DD-MM-YYYY (India)
  // Excel serial date number
  if (/^\d{5}(\.\d+)?$/.test(v)) {
    const d = new Date(Math.round((parseFloat(v) - 25569) * 86400 * 1000));
    if (!isNaN(d.getTime())) return d.toISOString().split('T')[0];
  }
  return null;
};

const normalizeTime = (raw: string): string => {
  const m = raw.trim().match(/^(\d{1,2}):(\d{2})/);
  return m ? `${pad(m[1])}:${m[2]}` : '00:00';
};

export interface CSVImportResult {
  transactions: Transaction[];
  skipped: number;
}

/** Reads a ledger CSV (the file produced by "Excel / CSV" export, also after editing in Excel). */
export const parseTransactionsCSV = (input: string): CSVImportResult => {
  const text = input.replace(/^\uFEFF/, '');
  const firstLine = text.split(/\r?\n/, 1)[0] || '';
  const delimiter = (firstLine.match(/;/g) || []).length > (firstLine.match(/,/g) || []).length ? ';' : ',';

  const rows = parseRows(text, delimiter);
  if (rows.length < 2) throw new Error('This file has no ledger entries.');

  const header = rows[0].map((h) => h.trim().toLowerCase());
  const find = (names: string[]): number => header.findIndex((h) => names.includes(h));
  const col = {
    id: find(['id']),
    date: find(['date']),
    time: find(['time']),
    name: find(['customer name', 'customer', 'name']),
    mobile: find(['mobile number', 'mobile', 'phone']),
    type: find(['category', 'type']),
    flow: find(['flow']),
    amount: find(['amount (inr)', 'amount']),
    method: find(['payment mode', 'payment method', 'payment']),
    notes: find(['notes', 'note']),
  };
  if (col.amount < 0 || col.flow < 0 || col.date < 0) {
    throw new Error('Not a ledger file (Date / Flow / Amount column missing).');
  }

  const get = (r: string[], i: number): string => (i >= 0 && i < r.length ? r[i].trim() : '');

  const transactions: Transaction[] = [];
  const usedIds = new Set<string>();
  let skipped = 0;

  rows.slice(1).forEach((r, index) => {
    const amount = parseFloat(get(r, col.amount).replace(/[₹,\s]/g, ''));
    const flowRaw = get(r, col.flow).toUpperCase();
    const flow: FlowType | null =
      flowRaw === 'TAKEN' || flowRaw === 'RECEIVED' ? 'TAKEN' : flowRaw === 'GIVEN' || flowRaw === 'PAID' || flowRaw === 'SENT' ? 'GIVEN' : null;
    const date = normalizeDate(get(r, col.date));

    if (!isFinite(amount) || amount < 0 || !flow || !date) {
      skipped++;
      return;
    }

    const time = normalizeTime(get(r, col.time));
    const typeRaw = get(r, col.type).toLowerCase();
    const type = TYPES.find((t) => t.toLowerCase() === typeRaw) || 'Other';
    const methodRaw = get(r, col.method).toLowerCase();
    const paymentMethod = METHODS.find((m) => m.toLowerCase() === methodRaw) || 'Cash';

    let id = get(r, col.id);
    if (!id || usedIds.has(id)) id = `tx-${Date.now().toString(36)}-${index}`;
    usedIds.add(id);

    const createdAt = new Date(`${date}T${time}:00`).getTime();

    transactions.push({
      id,
      customerName: get(r, col.name) || 'Unknown',
      mobileNumber: get(r, col.mobile).replace(/^'/, '').replace(/\.0+$/, ''),
      type,
      flow,
      amount,
      date,
      time,
      notes: get(r, col.notes) || undefined,
      paymentMethod,
      createdAt: isNaN(createdAt) ? Date.now() : createdAt,
    });
  });

  return { transactions, skipped };
};
