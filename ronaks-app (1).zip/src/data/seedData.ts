import { Transaction } from '../types';

export const getInitialTransactions = (): Transaction[] => {
  const today = new Date();
  const formatYMD = (d: Date) => d.toISOString().split('T')[0];
  
  const d0 = formatYMD(today);
  const d1 = formatYMD(new Date(today.getTime() - 1 * 24 * 60 * 60 * 1000));
  const d2 = formatYMD(new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000));

  return [
    {
      id: 'tx-101',
      customerName: 'Kailash Patel',
      mobileNumber: '9825147820',
      type: 'Mobile Repair',
      flow: 'TAKEN',
      amount: 1850,
      date: d0,
      time: '11:15',
      notes: 'Realme 9 Pro+ Display replacement (Combo) + Tempered glass',
      paymentMethod: 'UPI',
      createdAt: Date.now() - 3600000 * 4,
    },
    {
      id: 'tx-102',
      customerName: 'Jignesh Sharma',
      mobileNumber: '9974012398',
      type: 'Money Transfer',
      flow: 'TAKEN',
      amount: 5000,
      date: d0,
      time: '13:40',
      notes: 'Cash received for transfer to SBI A/c (Service charge ₹50 included)',
      paymentMethod: 'Cash',
      createdAt: Date.now() - 3600000 * 2,
    },
    {
      id: 'tx-103',
      customerName: 'Bank Remittance / Transfer Sent',
      mobileNumber: '9974012398',
      type: 'Money Transfer',
      flow: 'GIVEN',
      amount: 5000,
      date: d0,
      time: '13:42',
      notes: 'IMPS sent to SBI beneficiary for Jignesh',
      paymentMethod: 'Bank Transfer',
      createdAt: Date.now() - 3600000 * 2 + 120000,
    },
    {
      id: 'tx-104',
      customerName: 'Pooja Panchal',
      mobileNumber: '9428590123',
      type: 'Accessories',
      flow: 'TAKEN',
      amount: 450,
      date: d0,
      time: '15:20',
      notes: '33W Fast Charger + Type-C braided cable',
      paymentMethod: 'UPI',
      createdAt: Date.now() - 3600000 * 1,
    },
    {
      id: 'tx-105',
      customerName: 'Mahesh Solanki',
      mobileNumber: '9898234120',
      type: 'Mobile Repair',
      flow: 'GIVEN',
      amount: 700,
      date: d1,
      time: '12:30',
      notes: 'Spare part procurement (Samsung M31 Original Battery from distributor)',
      paymentMethod: 'Cash',
      createdAt: Date.now() - 86400000 - 3600000 * 5,
    },
    {
      id: 'tx-106',
      customerName: 'Mahesh Solanki',
      mobileNumber: '9898234120',
      type: 'Mobile Repair',
      flow: 'TAKEN',
      amount: 1400,
      date: d1,
      time: '17:15',
      notes: 'Samsung M31 battery replaced + Service charge received',
      paymentMethod: 'Cash',
      createdAt: Date.now() - 86400000 - 3600000 * 1,
    },
    {
      id: 'tx-107',
      customerName: 'Chirag Dave',
      mobileNumber: '9824056781',
      type: 'Accessories',
      flow: 'TAKEN',
      amount: 850,
      date: d2,
      time: '14:10',
      notes: 'Wireless Bluetooth Neckband + UV Curved Glass fitting',
      paymentMethod: 'UPI',
      createdAt: Date.now() - 172800000,
    },
  ];
};
