import React, { useRef, useState } from 'react';
import { X, Download, Upload, FileSpreadsheet, Trash2, RotateCcw, AlertTriangle, Check, ShieldCheck } from 'lucide-react';
import { Transaction } from '../types';
import { exportToCSV, exportToJSON } from '../utils/formatters';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  onImportData: (data: Transaction[]) => void;
  onClearAll: () => void;
  onResetDemo: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  transactions,
  onImportData,
  onClearAll,
  onResetDemo,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [clearInput, setClearInput] = useState('');

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportData(parsed);
          setImportStatus(`Successfully restored ${parsed.length} entries!`);
          setTimeout(() => {
            setImportStatus(null);
            onClose();
          }, 1500);
        } else {
          setImportStatus('Error: Invalid backup file format.');
        }
      } catch (err) {
        setImportStatus('Error: Could not parse backup file.');
      }
    };
    reader.readAsText(file);
  };

  const handleClearConfirmed = () => {
    if (clearInput.trim().toUpperCase() === 'CLEAR') {
      onClearAll();
      setShowClearConfirm(false);
      setClearInput('');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div 
        className="w-full max-w-lg bg-black border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800 bg-zinc-950">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded border border-white flex items-center justify-center font-mono font-bold text-xs bg-black text-white">
              47
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
                Data Management & Export
              </h2>
              <p className="text-[11px] font-mono text-zinc-400">
                The 47 • Local Storage & Cloud Backup
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5 text-sm">
          {/* Storage status badge */}
          <div className="p-3 rounded-xl border border-zinc-800 bg-zinc-950/70 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-zinc-300 shrink-0 mt-0.5" />
            <div className="text-xs font-mono space-y-0.5">
              <div className="font-semibold text-white">Local Storage Active</div>
              <p className="text-zinc-400 font-sans leading-relaxed">
                All records are securely saved directly in your browser/device storage. They remain intact even after closing the app.
              </p>
            </div>
          </div>

          {/* Export Options */}
          <div className="space-y-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Export Records
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={() => exportToCSV(transactions)}
                disabled={transactions.length === 0}
                className="p-3 rounded-lg border border-zinc-800 bg-zinc-950 hover:bg-zinc-900 hover:border-zinc-600 disabled:opacity-40 transition flex items-center space-x-3 text-left group"
              >
                <div className="p-2 rounded border border-zinc-700 bg-black text-white group-hover:border-white">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-mono text-xs font-bold text-white">Excel / CSV</div>
                  <div className="text-[10px] text-zinc-400">Ledger sheet</div>
                </div>
              </button>

              <button
                onClick={() => exportToJSON(transactions)}
                disabled={transactions.length === 0}
                className="p-3 rounded-lg border border-zinc-800 bg-zinc-950 hover:bg-zinc-900 hover:border-zinc-600 disabled:opacity-40 transition flex items-center space-x-3 text-left group"
              >
                <div className="p-2 rounded border border-zinc-700 bg-black text-white group-hover:border-white">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-mono text-xs font-bold text-white">JSON Backup</div>
                  <div className="text-[10px] text-zinc-400">All data archive</div>
                </div>
              </button>
            </div>
          </div>

          {/* Restore / Import */}
          <div className="space-y-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-300 font-medium">
              Restore from Backup
            </span>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".json"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full p-3 rounded-lg border border-zinc-800 bg-zinc-950 hover:bg-zinc-900 hover:border-zinc-600 transition flex items-center justify-between text-left"
            >
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded border border-zinc-700 bg-black text-white">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-mono text-xs font-bold text-white">Import JSON Backup File</div>
                  <div className="text-[10px] text-zinc-400">Restore previously downloaded ledger data</div>
                </div>
              </div>
              <span className="text-xs font-mono px-2.5 py-1 border border-zinc-700 rounded bg-black text-zinc-300">
                Choose File
              </span>
            </button>

            {importStatus && (
              <p className="text-xs font-mono text-zinc-300 pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-white" />
                <span>{importStatus}</span>
              </p>
            )}
          </div>

          {/* Danger Zone: Clear or Reset */}
          <div className="pt-2 border-t border-zinc-900 space-y-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-400 font-medium">
              Reset & Maintenance
            </span>
            
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <button
                onClick={onResetDemo}
                className="w-full sm:w-1/2 p-2.5 rounded-lg border border-zinc-800 bg-black text-zinc-300 hover:text-white hover:border-zinc-600 font-mono text-xs transition flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Demo Records</span>
              </button>

              <button
                onClick={() => setShowClearConfirm(true)}
                className="w-full sm:w-1/2 p-2.5 rounded-lg border border-zinc-900 bg-zinc-950 text-zinc-400 hover:text-white hover:border-zinc-700 font-mono text-xs transition flex items-center justify-center gap-2"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All Records</span>
              </button>
            </div>
          </div>

          {/* Clear Confirmation Dialog */}
          {showClearConfirm && (
            <div className="p-4 rounded-xl border border-zinc-700 bg-zinc-950 space-y-3">
              <div className="flex items-start gap-2.5 text-zinc-300 text-xs">
                <AlertTriangle className="w-4 h-4 text-white shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white uppercase font-mono">Are you completely sure?</div>
                  <p className="text-zinc-400 mt-0.5">
                    This will permanently delete all {transactions.length} records from this device. Type <strong>CLEAR</strong> to confirm.
                  </p>
                </div>
              </div>
              <input
                type="text"
                placeholder="Type CLEAR to confirm"
                value={clearInput}
                onChange={(e) => setClearInput(e.target.value)}
                className="w-full px-3 py-2 rounded border border-zinc-700 bg-black font-mono text-xs text-white uppercase focus:outline-none focus:border-white"
              />
              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 border border-zinc-800 rounded font-mono text-xs text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  disabled={clearInput.trim().toUpperCase() !== 'CLEAR'}
                  onClick={handleClearConfirmed}
                  className="px-3 py-1.5 bg-white text-black font-mono text-xs font-bold rounded border border-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-zinc-200"
                >
                  Confirm & Clear
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-zinc-800 bg-zinc-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-zinc-800 text-zinc-300 hover:text-white font-mono text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
