import { Transaction } from '../types';

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatDateDisplay = (dateStr: string): string => {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const targetDate = new Date(year, month - 1, day);
  
  const today = new Date();
  const todayYMD = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const targetYMD = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate()).getTime();

  const diffDays = Math.round((todayYMD - targetYMD) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';

  return targetDate.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

export const formatTimeDisplay = (timeStr: string): string => {
  if (!timeStr) return '';
  const [hours, minutes] = timeStr.split(':');
  const h = parseInt(hours, 10);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const displayH = h % 12 || 12;
  return `${displayH}:${minutes} ${ampm}`;
};

export const generateWhatsAppLink = (tx: Transaction): string => {
  const cleanPhone = tx.mobileNumber.replace(/\D/g, '');
  const phoneWithCode = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
  
  const flowText = tx.flow === 'TAKEN' ? 'Received' : 'Paid / Transferred';
  const message = `*Radhe Mobile — The 47 Ledger Receipt*\n` +
    `--------------------------------\n` +
    `*Customer:* ${tx.customerName}\n` +
    `*Service / Type:* ${tx.type}\n` +
    `*Amount:* ${formatCurrency(tx.amount)} (${flowText})\n` +
    `*Date:* ${formatDateDisplay(tx.date)} at ${formatTimeDisplay(tx.time)}\n` +
    (tx.notes ? `*Notes:* ${tx.notes}\n` : '') +
    `--------------------------------\n` +
    `Thank you for your business!\n` +
    `*Radhe Mobile* • Managed by Ronak Suthar`;

  return `https://wa.me/${phoneWithCode}?text=${encodeURIComponent(message)}`;
};

export const exportToCSV = (transactions: Transaction[]): void => {
  const headers = ['ID', 'Date', 'Time', 'Customer Name', 'Mobile Number', 'Category', 'Flow', 'Amount (INR)', 'Payment Mode', 'Notes'];
  
  const rows = transactions.map(t => [
    `"${t.id}"`,
    `"${t.date}"`,
    `"${t.time}"`,
    `"${t.customerName.replace(/"/g, '""')}"`,
    `"${t.mobileNumber}"`,
    `"${t.type}"`,
    `"${t.flow}"`,
    t.amount,
    `"${t.paymentMethod || 'Cash'}"`,
    `"${(t.notes || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `Radhe_Mobile_The47_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportToJSON = (transactions: Transaction[]): void => {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(transactions, null, 2));
  const link = document.createElement('a');
  link.setAttribute('href', dataStr);
  link.setAttribute('download', `The47_RadheMobile_Backup_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
